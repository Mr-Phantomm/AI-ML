print(5,"Arun")

"""

You can run Python in interactive mode
just type python/python3 in the terminal


"""
